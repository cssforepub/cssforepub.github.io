Licenses [
	Copyright @ Css 4 Epub
]
About [
	Version 1.00
	Stage beta
]
Style [
	title-name Front Matter
]
File [
	name epub-frontmatter-css.css
]
Download [
	from url|
	link [
	 	www.github/epubcssnew/download.html
	]
]